export async function handler() {
  const res = await fetch("https://finnhub.io/api/v1/quote?symbol=^VIX&token=cvtp9f1r01qjg135gre0cvtp9f1r01qjg135greg");
  const data = await res.json();
  return {
    statusCode: 200,
    body: JSON.stringify({ vix: data.c }),
    headers: { 'Content-Type': 'application/json' }
  };
}